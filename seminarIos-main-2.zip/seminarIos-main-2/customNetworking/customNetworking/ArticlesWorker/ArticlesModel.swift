//
//  WeirdStructure.swift
//  customNetworking
//
//  Created by MacBook Pro  on 15.12.23.
//

import Foundation

struct ArticlesModel: Decodable {
    let userId: Int
    let id: Int
    let title: String
    let completed: Bool
}
