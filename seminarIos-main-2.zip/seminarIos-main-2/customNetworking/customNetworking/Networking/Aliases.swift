//
//  Aliases.swift
//  customNetworking
//
//  Created by Aleksa Khruleva on 01.12.2023.
//

typealias RequestParameters = [(key: String, value: String)]
typealias HeaderModel = [String : String]
